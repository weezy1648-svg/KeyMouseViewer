package com.keymouseviewer;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.view.KeyEvent;
import android.view.InputDevice;
import android.view.accessibility.AccessibilityEvent;

public class KeyMouseAccessibilityService extends AccessibilityService {

    public static boolean isRunning = false;

    @Override
    public void onServiceConnected() {
        isRunning = true;
        AccessibilityServiceInfo info = new AccessibilityServiceInfo();
        info.eventTypes   = AccessibilityEvent.TYPE_VIEW_FOCUSED;
        info.feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC;
        info.flags        = AccessibilityServiceInfo.FLAG_REQUEST_FILTER_KEY_EVENTS;
        info.notificationTimeout = 100;
        setServiceInfo(info);
        if (MainActivity.instance != null) {
            MainActivity.instance.addEventFromService("Служба доступности подключена — глобальный перехват активен", "#00FF88");
        }
    }

    @Override
    protected boolean onKeyEvent(KeyEvent event) {
        if (event.getAction() == KeyEvent.ACTION_DOWN) {
            String src  = sourceName(event.getSource());
            String mods = modifiers(event);
            String key  = KeyEvent.keyCodeToString(event.getKeyCode()).replace("KEYCODE_", "");
            String text = "[" + src + "] " + mods + key;
            if (MainActivity.instance != null) {
                MainActivity.instance.addEventFromService(text, "#00CCFF");
            }
        }
        return false; // false = не поглощаем событие, передаём дальше
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {}

    @Override
    public void onInterrupt() {}

    @Override
    public void onDestroy() {
        super.onDestroy();
        isRunning = false;
    }

    private String sourceName(int src) {
        if ((src & InputDevice.SOURCE_KEYBOARD) != 0) return "Клавиатура";
        if ((src & InputDevice.SOURCE_MOUSE)    != 0) return "Мышь";
        if ((src & InputDevice.SOURCE_GAMEPAD)  != 0) return "Геймпад";
        if ((src & InputDevice.SOURCE_TOUCHPAD) != 0) return "Тачпад";
        return "Устройство";
    }

    private String modifiers(KeyEvent ev) {
        StringBuilder sb = new StringBuilder();
        if (ev.isCtrlPressed())  sb.append("Ctrl+");
        if (ev.isAltPressed())   sb.append("Alt+");
        if (ev.isShiftPressed()) sb.append("Shift+");
        if (ev.isMetaPressed())  sb.append("Win+");
        return sb.toString();
    }
}
