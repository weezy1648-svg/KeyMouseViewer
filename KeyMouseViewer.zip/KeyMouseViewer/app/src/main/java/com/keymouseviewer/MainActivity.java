package com.keymouseviewer;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.InputDevice;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    public static MainActivity instance;

    private LinearLayout eventContainer;
    private ScrollView scrollView;
    private TextView tvAccessibilityStatus;
    private Button btnClear;
    private Button btnAccessibility;

    private int eventCount = 0;
    private static final int MAX_EVENTS = 150;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss.SSS", Locale.getDefault());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        instance = this;

        eventContainer        = findViewById(R.id.event_container);
        scrollView            = findViewById(R.id.scroll_view);
        tvAccessibilityStatus = findViewById(R.id.tv_accessibility_status);
        btnClear              = findViewById(R.id.btn_clear);
        btnAccessibility      = findViewById(R.id.btn_accessibility);

        btnClear.setOnClickListener(v -> {
            eventContainer.removeAllViews();
            eventCount = 0;
            addRow("Лог очищен", "#444444", false);
        });

        btnAccessibility.setOnClickListener(v ->
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));

        addRow("KeyMouseViewer запущен", "#00FF88", false);
        addRow("Подключите клавиатуру или мышь по USB / Bluetooth", "#888888", false);
        updateAccessibilityBanner();
    }

    @Override
    protected void onResume() {
        super.onResume();
        instance = this;
        updateAccessibilityBanner();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (instance == this) instance = null;
    }

    private void updateAccessibilityBanner() {
        if (KeyMouseAccessibilityService.isRunning) {
            tvAccessibilityStatus.setText("OK Служба доступности АКТИВНА");
            tvAccessibilityStatus.setBackgroundColor(Color.parseColor("#0D2B1A"));
            tvAccessibilityStatus.setTextColor(Color.parseColor("#00FF88"));
            btnAccessibility.setVisibility(View.GONE);
        } else {
            tvAccessibilityStatus.setText("ВЫКЛ Служба доступности отключена - нажмите кнопку");
            tvAccessibilityStatus.setBackgroundColor(Color.parseColor("#2B1A0D"));
            tvAccessibilityStatus.setTextColor(Color.parseColor("#FFA500"));
            btnAccessibility.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        if (event.getAction() == KeyEvent.ACTION_DOWN) {
            String src  = sourceName(event.getSource());
            String mods = modifiers(event);
            String key  = KeyEvent.keyCodeToString(event.getKeyCode()).replace("KEYCODE_", "");
            addRow("[" + src + "] " + mods + key, "#00CCFF", true);
        }
        return super.dispatchKeyEvent(event);
    }

    @Override
    public boolean dispatchGenericMotionEvent(MotionEvent ev) {
        if ((ev.getSource() & InputDevice.SOURCE_MOUSE) != 0) {
            handleMouse(ev);
            return true;
        }
        return super.dispatchGenericMotionEvent(ev);
    }

    private void handleMouse(MotionEvent ev) {
        String msg; String color;
        switch (ev.getAction()) {
            case MotionEvent.ACTION_BUTTON_PRESS:
                msg   = mouseBtn(ev.getActionButton()) + " нажата";
                color = "#FF4466";
                break;
            case MotionEvent.ACTION_BUTTON_RELEASE:
                msg   = mouseBtn(ev.getActionButton()) + " отпущена";
                color = "#FF8844";
                break;
            case MotionEvent.ACTION_SCROLL:
                float v = ev.getAxisValue(MotionEvent.AXIS_VSCROLL);
                float h = ev.getAxisValue(MotionEvent.AXIS_HSCROLL);
                if      (v > 0) { msg = "Прокрутка ВВЕРХ";   color = "#FFDD00"; }
                else if (v < 0) { msg = "Прокрутка ВНИЗ";    color = "#FFDD00"; }
                else if (h > 0) { msg = "Прокрутка ВПРАВО";  color = "#FFDD00"; }
                else            { msg = "Прокрутка ВЛЕВО";   color = "#FFDD00"; }
                break;
            default: return;
        }
        String pos = String.format(Locale.US, " (%.0f, %.0f)", ev.getX(), ev.getY());
        addRow(msg + pos, color, true);
    }

    private String mouseBtn(int btn) {
        switch (btn) {
            case MotionEvent.BUTTON_PRIMARY:   return "ЛКМ";
            case MotionEvent.BUTTON_SECONDARY: return "ПКМ";
            case MotionEvent.BUTTON_TERTIARY:  return "Средняя";
            case MotionEvent.BUTTON_BACK:      return "Назад";
            case MotionEvent.BUTTON_FORWARD:   return "Вперед";
            default:                           return "Кнопка " + btn;
        }
    }

    private String sourceName(int src) {
        if ((src & InputDevice.SOURCE_KEYBOARD) != 0) return "Клавиатура";
        if ((src & InputDevice.SOURCE_MOUSE)    != 0) return "Мышь";
        if ((src & InputDevice.SOURCE_GAMEPAD)  != 0) return "Геймпад";
        if ((src & InputDevice.SOURCE_TOUCHPAD) != 0) return "Тачпад";
        return "Устройство";
    }

    private String modifiers(KeyEvent ev) {
        StringBuilder sb = new StringBuilder();
        if (ev.isCtrlPressed())  sb.append("Ctrl+");
        if (ev.isAltPressed())   sb.append("Alt+");
        if (ev.isShiftPressed()) sb.append("Shift+");
        if (ev.isMetaPressed())  sb.append("Win+");
        return sb.toString();
    }

    public void addEventFromService(String text, String hexColor) {
        mainHandler.post(() -> addRow(text, hexColor, true));
    }

    private void addRow(String text, String hexColor, boolean withTime) {
        if (eventCount >= MAX_EVENTS) {
            if (eventContainer.getChildCount() > 0)
                eventContainer.removeViewAt(0);
        }
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(16, 10, 16, 10);
        row.setBackgroundColor(eventCount % 2 == 0
                ? Color.parseColor("#0C0C0C") : Color.parseColor("#141414"));

        View bar = new View(this);
        LinearLayout.LayoutParams barLp = new LinearLayout.LayoutParams(5, LinearLayout.LayoutParams.MATCH_PARENT);
        barLp.setMargins(0, 3, 14, 3);
        bar.setLayoutParams(barLp);
        bar.setBackgroundColor(Color.parseColor(hexColor));

        TextView tv = new TextView(this);
        tv.setText(withTime ? "[" + sdf.format(new Date()) + "] " + text : text);
        tv.setTextColor(Color.parseColor(hexColor));
        tv.setTextSize(13f);
        tv.setTypeface(android.graphics.Typeface.MONOSPACE);
        tv.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        row.addView(bar);
        row.addView(tv);
        eventContainer.addView(row);
        eventCount++;
        scrollView.post(() -> scrollView.fullScroll(View.FOCUS_DOWN));
    }
}
